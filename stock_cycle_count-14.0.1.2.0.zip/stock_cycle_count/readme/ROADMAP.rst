* Assess the possibility to refactor `action_compute_cycle_count_rules` method
  converting some of the searches to actual fields. E.g.
  `inventory_history_ids` for all the inventories done in a location.
