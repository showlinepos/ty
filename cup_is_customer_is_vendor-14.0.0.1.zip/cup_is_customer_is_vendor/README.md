"# cup_is_customer_is_vendor" 
