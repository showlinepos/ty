# -*- coding: utf-8 -*-

from . import purchase
from . import res_partner
from . import sale