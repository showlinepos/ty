# -*- coding: utf-8 -*-
##########################################################################
# Author      : Nevioo Technologies (<https://nevioo.com/>)
# Copyright(c): 2020-Present Nevioo Technologies
# All Rights Reserved.
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
# You should have received a copy of the License along with this program.
##########################################################################
{
    "name":  "Enable Zero Amount Invoice / Bill Validation",
    "summary":  "This module will allow you to restrict the Invoice / Credit Notes / Bill / Refund / Journal Entries if the amount is zero.",
    "category":  "Account",
    "version":  "14.0.1.1",
    "sequence":  1,
    "author":  "Nevioo Technologies",
    "website":  "www.nevioo.com",
    "license": 'OPL-1',
    "images": [],
    'depends': ['base', 'account'],
    'data': [
                "views/res_confing_view.xml"
            ],
    "application":  True,
    "installable":  True,
    "auto_install":  False,
}
