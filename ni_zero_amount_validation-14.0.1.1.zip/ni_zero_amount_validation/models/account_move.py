from odoo import fields, models, api, _
from odoo.exceptions import UserError

class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_post(self):
        if self.env.user.company_id.ni_zero_amount_enable==True and self.amount_total==0:
            raise UserError(_("You can't validate Zero amount record"))
        return super(AccountMove, self).action_post()