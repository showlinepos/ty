# -*- coding: utf-8 -*-
from odoo import api, fields, models,_

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    ni_zero_amount_enable = fields.Boolean(string="Enable Zero Amount Validation?")

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(ni_zero_amount_enable=self.env.user.company_id.ni_zero_amount_enable)
        return res

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env.user.company_id.write({'ni_zero_amount_enable': self.ni_zero_amount_enable or False })


class ResCompany(models.Model):
    _inherit = 'res.company'

    ni_zero_amount_enable = fields.Boolean(string="Enable Zero Amount Validation?")
