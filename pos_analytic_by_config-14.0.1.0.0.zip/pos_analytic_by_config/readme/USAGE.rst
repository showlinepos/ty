To configure this module, you need to:

* Go to Point of Sale > Configuration > Point of Sales
* Open an  existing or create a new one
* You can put an analytic account on the current point of sale (pos.config)
