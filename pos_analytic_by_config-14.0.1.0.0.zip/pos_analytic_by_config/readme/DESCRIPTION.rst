This module allows to use analytic account defined on POS configuration
for invoices and accounting entries generated from POS orders.
