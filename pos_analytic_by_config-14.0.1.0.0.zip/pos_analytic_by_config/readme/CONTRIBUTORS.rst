* `ACSONE SA/NV <https://www.acsone.eu>`_

  * Adrien Peiffer <adrien.peiffer@acsone.eu>
  * Cédric Pigeon <cedric.pigeon@acsone.eu>
  * Xavier Bouquiaux <xavier.bouquiaux@acsone.eu>

* `Tecnativa <https://www.tecnativa.com>`_

  * David Vidal
