{
    'name' : 'Periodical Report',
    'version' : '14.0.1',
    'summary': 'This module allow us to print period wise sale and purchase report.',
    'sequence': 16,
    'category': 'Sales',
    'author': 'YC Solutions, India',
    'company': 'YC Solutions, India',
    'description': """
        Custom Sales and Purchase Report
        =====================================
        This module print daily, last week and last month sales and purchase report.
        Also print report for particular duration.
    """,
    "license": "LGPL-3",
    'depends' : ['base_setup', 'sale_management', 'purchase'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/wiz_periodical_report_view.xml',
        'views/periodical_report.xml',
        'views/report_periodical_sales.xml'
    ],
    'images': [
        'static/description/banner.gif'
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
