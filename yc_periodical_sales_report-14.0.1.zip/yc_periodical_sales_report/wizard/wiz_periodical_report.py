from odoo import api, fields, models


class PeriodicalReportWizard(models.TransientModel):
    _name = "periodical.report.wizard"


    report_types=fields.Selection([
        ('sale_report', 'Sale Report'),
        ('purchase_report', 'Purchase Report'),
        ],
        'Report Type',
         default='sale_report',)
    period = fields.Selection([
        ('today', 'Today'),
        ('last_week', 'Last Week'),
        ('last_month','Last Month')],
        'Period',
         default='today',
        help="Select the option for priting report for daily, "
             "weekly or monthly")
    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('purchase', 'Purchase Order'),
        ('to approve', 'To Approve'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ('all', 'All')
    ], string='Status', default='all')
    date_from = fields.Date(string='Start Date')
    date_to = fields.Date(string='End Date')


    def check_report(self):
        period = self._fields['period'].get_values(self.env)
        data = {
            'ids': self.ids,
            'model': self._name,
            'form': {
                'date_from': self.date_from,
                'date_to': self.date_to,
                'period' : self.period,
                'state' : self.state,
                'report_types':self.report_types
            },
        }
        return self.env.ref('yc_periodical_sales_report.action_report_periodical_sales').report_action(self, data=data)
