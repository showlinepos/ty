from odoo import api, models
from dateutil.relativedelta import relativedelta
import datetime


class ReportPeriodicalSale(models.AbstractModel):
    _name = 'report.yc_periodical_sales_report.report_periodical_sales'

    @api.model
    def _get_report_values(self, docids, data=None):
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']
        period = data['form']['period']
        state = data['form']['state']
        report_types = data['form']['report_types']
        total_sale = 0.0
        period_value = ''
        print('.............,,,,,,,,,,,..........', data)

        if date_from and date_to:
            domain = [('date_order', '>=', date_from),
                      ('date_order', '<=', date_to)]
        else:
            if period == 'today':
                domain = [('date_order', '>=', datetime.datetime.now()
                           .strftime('%Y-%m-%d 00:00:00')), ('date_order',
                                                             '<=', datetime.datetime.now()
                                                             .strftime('%Y-%m-%d 23:59:59'))]
                period_value = 'Today'
            elif period == 'last_week':
                domain = [('date_order', '>=', (datetime.date.today()
                                                - datetime.timedelta(days=7)).strftime('%Y-%m-%d 00:00:00')),
                          ('date_order', '<=', datetime.datetime.now()
                           .strftime('%Y-%m-%d 23:59:59'))
                          ]
                period_value = 'Last Week'
            elif period == 'last_month':
                domain = [
                    ('date_order', '>=',
                     (datetime.date.today() - relativedelta(months=1)).
                     strftime('%Y-%m-%d 00:00:00')),
                    ('date_order', '<=',
                     datetime.datetime.now().strftime('%Y-%m-%d 23:59:59'))
                ]
                period_value = 'Last Month'
        if state != 'all':
            domain.append(('state', '=', state))

        sale_orders = []
        if report_types =='sale_report':
            orders = self.env['sale.order'].search(domain)
        elif report_types == 'purchase_report':
            orders = self.env['purchase.order'].search(domain)
        else:
            orders = self.env['sale.order'].search(domain)



        for order in orders:
            sale_orders.append({
                'name': order.name,
                'date_order': order.date_order,
                'partner': order.partner_id.name,
                'amount_total': order.amount_total,
                'state': dict(order._fields['state'].selection).get(order.state)
            })
            total_sale += order.amount_total
        return {
            'doc_ids': data['ids'],
            'doc_model': data['model'],
            'period': period_value,
            'date_from': date_from,
            'date_to': date_to,
            'sale_orders': sale_orders,
            'total_sale': total_sale,
            'report_types': report_types,
        }
