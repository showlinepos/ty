odoo.define('bi_pos_a4_size_receipt.ReceiptScreen', function(require) {
	"use strict";

	const Registries = require('point_of_sale.Registries');
	const ReceiptScreen = require('point_of_sale.ReceiptScreen');

	const BiReceiptScreen = (ReceiptScreen) =>
		class extends ReceiptScreen {
            constructor() {
				super(...arguments);
			}

			async print_a4_size_receipt(){
                var self = this;
                var pos_session_id = self.env.pos.pos_session.id;
                if(self.env.pos.config.allow_a4_size_receipt && !self.env.pos.config.allow_arabic_labels ){
                    await this.env.pos.do_action('bi_pos_a4_size_receipt.action_print_pos_report', {
                        additional_context: {
                            active_ids: [self.env.pos.pos_session.id],
                        },
                    });
                }
                if(self.env.pos.config.allow_a4_size_receipt && self.env.pos.config.allow_arabic_labels){
                    await this.env.pos.do_action('bi_pos_a4_size_receipt.action_print_arabic_pos_report', {
                        additional_context: {
                            active_ids: [self.env.pos.pos_session.id],
                        },
                    });
                }
			}
		};

	Registries.Component.extend(ReceiptScreen, BiReceiptScreen);

	return ReceiptScreen;

});
