
Version 14.0.0.1: (06/01/22)
		- Change layout for reduce height of qrcode and make logo ,qrcode and address in align.
        - Add spacing between total section  and lines as per reference index and reduce footer width.

Version 14.0.0.2: (17/05/22)
        - Change field name and change format rename config string.
