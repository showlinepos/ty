# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

import base64
from odoo import fields, models, api, _
from odoo.tools import float_repr


class PosConfig(models.Model):
    _inherit = "pos.config"

    allow_a4_size_receipt = fields.Boolean(string="Allow A4 Size Receipt Print")
    allow_arabic_labels = fields.Boolean(string="Allow Arabic Labels For Receipt")


class PosOrderInherit(models.Model):
    _inherit = 'pos.order'

    qr_code_str = fields.Char(string='QR Code', compute='_compute_qr_code_str')

    @api.depends('date_order', 'company_id', 'name', 'amount_total', 'amount_tax')
    def _compute_qr_code_str(self):
        def get_qr_encoding(tag, field):
            company_name_byte_array = field.encode()
            company_name_tag_encoding = tag.to_bytes(length=1, byteorder='big')
            company_name_length_encoding = len(company_name_byte_array).to_bytes(length=1, byteorder='big')
            return company_name_tag_encoding + company_name_length_encoding + company_name_byte_array

        docid = self.search([], order='id desc')[0].id
        record = self.browse(docid)
        qr_code_str = ''
        if record.date_order and record.partner_id:
            order_name = get_qr_encoding(1, record.name)
            partner = get_qr_encoding(2, record.partner_id.name)
            time_sa = fields.Datetime.context_timestamp(self.with_context(tz='Asia/Riyadh'), record.date_order)
            timestamp_enc = get_qr_encoding(3, time_sa.isoformat())
            amount_total = get_qr_encoding(4, float_repr(abs(record.amount_total), 2))
            amount_tax = get_qr_encoding(5, float_repr(abs(record.amount_tax), 2))
            str_to_encode = order_name + partner + timestamp_enc + amount_total + amount_tax
            qr_code_str = base64.b64encode(str_to_encode).decode()
        record.qr_code_str = qr_code_str

    def get_order(self):
        docid = self.search([], order='id desc')[0].id
        record_data = self.browse(docid)
        rec_lines = record_data.lines
        total_disc = 0
        grand_total = 0
        for line in rec_lines:
            total_disc += (line.price_unit * line.qty) - line.price_subtotal
            grand_total += line.price_subtotal
        return {
            'record_data': record_data,
            'total_disc': total_disc,
            'grand_total': grand_total,
        }

    def get_partner_data(self):
        docid = self.search([], order='id desc')[0].id
        record_data = self.browse(docid)
        partner_id = self.env['res.partner'].browse(record_data.partner_id.id)
        return {
            'mobile': partner_id.mobile,
            'phone': partner_id.phone
        }
