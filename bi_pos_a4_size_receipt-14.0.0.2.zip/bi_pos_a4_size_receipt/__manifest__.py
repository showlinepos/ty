# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
{
    'name': 'POS A4 Size Report/POS Arabic Invoice Report',
    'version': '14.0.0.2',
    'category': 'Point of Sale',
    'summary': 'Point of Sale A4 Size Report  point of sale A4 size receipt POS Receipt QR code on POS Receipt POS QR code Receipt POS Arabic receipt pos Arabic invoice report pos A4 receipt pos a4 invoice report pos Arabic label receipt print pos Arabic receipt on pos',
    'description': """

            POS A4 Size Report in odoo,
            Print A4 Size Receipt in odoo,
            Print A4 Size Receipt with a QR code in odoo,
            Add Arabic Labels in A4 Size Receipt in odoo,
            Arabic Labels in odoo,
            A4 Size Receipt Report in odoo,

    """,
    'author': 'BrowseInfo',
    "price": 18,
    "currency": 'EUR',
    'website': 'https://www.browseinfo.in',
    'depends': ['base', 'point_of_sale'],
    'data': [
        'report/pos_receipt_card.xml',
        'report/pos_receipt_report.xml',
        'report/pos_arabic_receipt.xml',
        'report/pos_arabic_receipt_report.xml',
        'views/pos_config_views.xml',
        'views/pos_assets_common.xml',
    ],
    'qweb': [
        'static/src/xml/Screens/ReceiptScreen.xml',
    ],
    'auto_install': False,
    'installable': True,
    'live_test_url':'https://youtu.be/JMFQ7DUNOkg',
    'images':["static/description/Banner.png"],
}

