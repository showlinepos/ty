* Jordi Esteve <jesteve@zikzakmedia.com>
* Lorenzo Battistini <https://github.com/eLBati>
* Alex Comba <alex.comba@agilebg.com> (OpenERP v7 port)
* Bruno Bottacini <bruno.bottacini@dorella.com> (OpenERP v7 port)
* Andrea Cometa <info@andreacometa.it> (Odoo v8 port)
* `Tecnativa <https://www.tecnativa.com>`_:

    * Pedro M. Baeza
    * Carlos Dauden

* Jordi Ballester <jordi.ballester@forgeflow.com> (Odoo v9 port)
* Maxime Chambreuil <mchambreuil@ursainfosystems.com>
* Javi Dios <javi@ozonomultimedia.com> (Odoo v11 port)
* Simone Vanin <simone.vanin@agilebg.com>
