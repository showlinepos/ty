To use this module, you need to :

Go to Settings > Manage Access Rights > (Select your user) > Activate "Show Full Accounting Features"
