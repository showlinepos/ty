## Module <om_hr_payroll_account>

#### 08.04.2022
#### Version 14.0.4.0.0
##### IMP
- cancel payslip

#### 01.02.2022
#### Version 14.0.3.1.0
##### FIX
- journal account
