odoo.define('aos_whatsapp_pos.ReceiptScreen', function(require) {
    'use strict';

    const { useRef } = owl.hooks;
    //const { is_whatsapp } = require('web.utils');
    //const { useErrorHandlers, onChangeOrder } = require('point_of_sale.custom_hooks');
    const { useListener } = require('web.custom_hooks');
    const { useContext } = owl.hooks;
    const { Printer } = require('point_of_sale.Printer');
    const PosComponent = require('point_of_sale.PosComponent');
    const OrderManagementScreen = require('point_of_sale.OrderManagementScreen');
    const ReceiptScreen = require('point_of_sale.ReceiptScreen');
    const Registries = require('point_of_sale.Registries');
    const OrderReceipt = require('point_of_sale.OrderReceipt');
    //const AbstractReceiptScreen = require('point_of_sale.AbstractReceiptScreen');
    const contexts = require('point_of_sale.PosContext');

    const WhatsappReceiptScreen = ReceiptScreen =>
        class extends ReceiptScreen {
            constructor() {
                super(...arguments);
				this.orderReceiptWhatsApp = useRef('order-receipt');
				const order = this.currentOrder;
                const client = order.get_client();
				const orderName = order.get_name();
				const pos_config = this.env.pos.config;
				let message = pos_config.whatsapp_default_message.replace("_CUSTOMER_", client && client.name || 'Customer');
				//console.log('==WhatsappReceiptScreen=1=',order)
                this.orderUiState = useContext(order.uiState.ReceiptScreen);
                this.orderUiState.inputWhatsapp = this.orderUiState.inputWhatsapp || (client && client.whatsapp) || '';
                this.orderUiState.inputMessage = message + ' ' + orderName +'.';
				//setTimeout(async () => await this.onSendWhatsapp(), 0);
				console.log('==WhatsappReceiptScreen=2=',this.orderUiState.inputWhatsapp,this.orderUiState.inputMessage)
				if (this.orderUiState.inputWhatsapp || this.orderUiState.inputWhatsapp != '0') {
                    setTimeout(async () => await this.onSendWhatsapp(), 0);
                }
            }
            /**
             * @override
             */
			/*whenClosing() {
                this.orderDone();
            }*/
			/*async xonSendWhatsapp() {
                var order = this.currentOrder;
                var self = this;
                var customer = this.currentOrder.changed.client;
                var message = this.env._t('Dear *' + customer.name + '*,\nHere is your electronic ticket for the *' + order.name + '*');
                var newContext = {
                    'receipt_data': this.orderReceiptWhatsApp.el.outerHTML,
                    'active_model': 'pos.order',
                    'active_id': order.name,
                };
                var context = _.extend(this.env.session.user_context || {}, newContext);
				const client = order.get_client();
				const orderName = order.get_name();
				const orderClient = { order: order, whatsapp: this.orderUiState.inputWhatsapp, message: this.orderUiState.inputMessage, name: client ? client.name : this.orderUiState.inputWhatsapp };			
				const order_server_id = this.env.pos.validated_orders_name_server_id_map[orderName];
				await this.rpc({
                    model: 'pos.order',
                    method: 'action_whatsapp_to_customer',
                    args: [[order_server_id], orderName, orderClient],
					kwargs: { context: newContext },
                });
            }*/

            async onSendWhatsapp() {
                if (!this.orderUiState.inputWhatsapp) {
                    this.orderUiState.whatsappSuccessful = false;
                    this.orderUiState.whatsappNotice = this.env._t('Whatsapp number is empty.');
                    return;
                }
                try {
                    await this._sendWhatsappToCustomer();
					//console.log('==SEND==')
                    this.orderUiState.whatsappSuccessful = true;
                    this.orderUiState.whatsappNotice = 'Whatsapp sent.'
                } catch (error) {
					console.log('==ERROR==',error)
                    this.orderUiState.whatsappSuccessful = false;
                    this.orderUiState.whatsappNotice = 'Sending Whatsapp failed. Please try again.'
                }
                //console.log('=onSendWhatsapp=',this._sendWhatsappToCustomer())
            }
            
            async _sendWhatsappToCustomer() {
				const printer = new Printer(null, this.env.pos);
				const receiptString = this.orderReceiptWhatsApp.el.outerHTML;
                const ticketImage = await printer.htmlToImg(receiptString);
				const order = this.currentOrder;
				const client = order.get_client();
				const orderName = order.get_name();
				const orderClient = { order: order, whatsapp: this.orderUiState.inputWhatsapp, message: this.orderUiState.inputMessage, name: client ? client.name : this.orderUiState.inputWhatsapp };			
				const order_server_id = this.env.pos.validated_orders_name_server_id_map[orderName];
				await this.rpc({
                    model: 'pos.order',
                    method: 'action_send_whatsapp_to_customer',
                    args: [[order_server_id], orderName, orderClient, ticketImage],
					/*kwargs: { context: newContext },*/
                });
            }
        };
	Registries.Component.extend(ReceiptScreen, WhatsappReceiptScreen);
	//Registries.Component.addByExtending(ReceiptScreen, AbstractReceiptScreen);
    //Registries.Component.extend(ReceiptScreen, ReceiptScreen);

    return ReceiptScreen;
});
