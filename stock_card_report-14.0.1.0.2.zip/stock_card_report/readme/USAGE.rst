To use this module, you need to:

#. Go to Inventory > Reporting > Stock Card.
#. Select Start date, End date, Products, Location.
#. Choose View or Export PDF or Export XLSX or Cancel.
