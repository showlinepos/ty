* Cannot pay invoices in a different currency than that defined in the journal
  associated to the payment method used to pay/collect payment.

* Should depend on `pos_invoicing` but it requires a refactoring of `pos_invoicing`.
  It will be improved when migrating to 13.0
