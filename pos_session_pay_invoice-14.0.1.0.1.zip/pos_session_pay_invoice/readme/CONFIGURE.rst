#.  Go to *Point of Sale / Configuration / Point of Sale* and activate the
    'Cash Control' setting.
