=============================
POS Clear Cart V14
=============================

This modlue helps to ease the customer's shopping experience by emptying the 
cart at once by clicking one button. Customers can use this “Clear Cart” 
button to flush out all the cart products with a single click.

Installation
============

To install this module, you need to install: point_of_sale

Download the module and add it to your Odoo addons folder. Afterward, log on to
your Odoo server and go to the Apps menu. Trigger the debug mode and update the
list by clicking on the "Update Apps List" link. Now install the module by
clicking on the install button.

Upgrade
============

To upgrade this module, you need to:

Download the module and add it to your Odoo addons folder. Restart the server
and log on to your Odoo server. Select the Apps menu and upgrade the module by
clicking on the upgrade button.


Configuration
=============

No additional configurations needed


Credits
=======

Contributors
------------

* Botspot Infoware Pvt. Ltd. <contact@botspotinfoware.com>


Author & Maintainer
-------------------

This module is maintained by the Botspot Infoware Pvt. Ltd.
