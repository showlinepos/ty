Restrict some users to only access their assigned points of sale.
