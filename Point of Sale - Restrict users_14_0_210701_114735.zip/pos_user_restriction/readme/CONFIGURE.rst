With a POS Manager, open a point of sale configration (pos.config) and set "Assigned users" field.

Then, assign "User: Assigned POS Only" group to users who should be able to access to their assigned points of sale only.

Allowed Employees
Then assign "Authorized Employees" employee the same user "Assigned POS Only" Use employee credentials to log in to the PoS session and switch cashier.
