.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
    :alt: License: AGPL-3

=====================
Stock Adjustment Cost
=====================

Adds product cost field to inventory adjustment line view.

Usage
=====

* Go to Inventory > Operations > Inventory Adjustments
* Create or open an existing inventory adjustment
* On the list view you should see the Product Cost field and it should show the cost of the product.

Contributors
------------

* Open Source Integrators <contact@opensourceintegrators.com>
