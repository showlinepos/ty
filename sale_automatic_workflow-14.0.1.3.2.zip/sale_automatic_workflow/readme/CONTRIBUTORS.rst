* Guewen Baconnier
* Beau Sebastien
* Leonardo Pistone
* Stéphane Bidoul
* Damien Crier
* Alexandre Fayolle
* Sodexis
* Dave Lasley <dave@laslabs.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Thomas Fossoul <thomas@niboo.com>
* Phuc Tran Thanh <phuc@trobz.com>
