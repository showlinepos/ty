## Module <product_multi_uom_pos>

#### 26.11.2020
#### Version 14.0.1.0.0
#### Migration
Migration Of POS Product Multiple UOM




