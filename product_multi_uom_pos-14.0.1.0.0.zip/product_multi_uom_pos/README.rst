========================
POS Product Multiple UOM
========================

Added option to update the uom of products in pos.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Usage
=====

After installation, go to Inventory -> Settings
 and enable the multiple uom option under the 'Products' section.

Known issues / Roadmap
======================

* ...

Bug Tracker
===========

Contact odoo@cybrosys.com

Contributors
------------

* Version 10: Linto CT  <linto@cybrosys.in>
* Version 10: Shereef PT <shereef@cybrosys.in>
* Version 12: Mehjabin Farsana <mehjabin@cybrosys.in>
* Version 13: Mehjabin Farsana <mehjabin@cybrosys.in>
* Version 14: Jibin James <jibin@cybrosys.in>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
