# -*- coding: utf-8 -*-

from . import res_user_read_only