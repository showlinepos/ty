This module adds an additional reporting on Inventory side where warehouse
location quantities are shown by all stockable products.
