Simply install this addon, search a product in point of sale, and click on the product you want to add to the order, you'll see the search is cleared when you click.
