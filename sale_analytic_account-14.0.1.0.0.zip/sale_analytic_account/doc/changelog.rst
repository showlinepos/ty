v1.0.0
======
* Automatic creation for sale analytic account
