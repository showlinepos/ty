* Alexis de Lattre <alexis.delattre@akretion.com>
* Javier Iniesta <javieria@antiun.com>
* Luis M. Ontalba <luis.martinez@tecnativa.com>
* David Vidal <david.vidal@tecnativa.com>
* Thore Baden
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
* Reyes4711
* Denis Roussel <denis.roussel@acsone.eu>
