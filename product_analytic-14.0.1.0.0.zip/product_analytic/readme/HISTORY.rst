13.0.1.0.0 (2020-01-08)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 13.

12.0.1.0.0 (2019-05-26)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 12.

11.0.1.0.0 (2018-05-18)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 11.

10.0.1.0.1 (2017-07-18)
~~~~~~~~~~~~~~~~~~~~~~~

[ADD] Demo data and feature to set analytic account for products.

10.0.1.0.0 (2017-06-13)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 10.

8.0.1.0.2 (2016-12-03)
~~~~~~~~~~~~~~~~~~~~~~~

[FIX] Travis errors.

8.0.1.0.1 (2016-01-05)
~~~~~~~~~~~~~~~~~~~~~~~

[IMP] Analytic account creating invoice lines.

8.0.1.0.0 (2015-11-30)
~~~~~~~~~~~~~~~~~~~~~~~

First version.
