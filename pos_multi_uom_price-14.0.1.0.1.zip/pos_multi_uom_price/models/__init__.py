# -*- coding: utf-8 -*-

from . import product_multi_uom_price
from . import product_template
from . import pos_order
from . import stock_picking
