# from odoo.tests.common import TransactionCase, Form
#
# class TestProject(TransactionCase):
#     def test_create_project(self):
#         project_from = Form(self.env['real.estate.project'])
#         project_from.name = 'ABC'
#         project_from.save()

