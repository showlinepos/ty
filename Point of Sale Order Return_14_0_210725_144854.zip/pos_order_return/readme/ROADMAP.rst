When migrating the module ``pos_order_return`` in version > 12.0 please merge
both modules ``pos_order_return`` and ``pos_order_return_traceability`` into a
single module.
