* Sylvain LE GAL <https://twitter.com/legalsylvain>
* David Vidal <david.vidal@tecnativa.com>
* Kiril Vangelovski <kiril@lambda-is.com>
* Druidoo <https://www.druidoo.io>
* Dhara Solanki <dhara.solanki@initos.com>
