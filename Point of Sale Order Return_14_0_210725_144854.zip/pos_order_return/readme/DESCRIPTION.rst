This module extends the functionality of odoo Point Of Sale about POS Order
returns.

With this module, it is now forbidden to return more quantity than the initial
one.

A link is created between the returned Order and the initial Order.
A link is created between the returned Order Line and the initial Order Line.
