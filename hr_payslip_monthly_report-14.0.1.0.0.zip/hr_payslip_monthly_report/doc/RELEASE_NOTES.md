## Module <hr_payslip_monthly_report>

#### 29.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial commit

