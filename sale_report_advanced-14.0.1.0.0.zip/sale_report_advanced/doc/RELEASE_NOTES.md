## Module <advanced sales reports>

#### 27.4.2022
#### Version 14.0.1.0.0
##### ADD
- Initial Commit for sale_report_advanced
