# -*- coding: utf-8 -*-

from . import profit_report_render_file
