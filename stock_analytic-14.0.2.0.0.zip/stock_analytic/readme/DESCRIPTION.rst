Adds an analytic account and analytic tags in stock move to be able to get
analytic information when generating the journal items.
