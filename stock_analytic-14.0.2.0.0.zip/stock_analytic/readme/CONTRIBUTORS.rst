* Hanane ELKHAL <hanane@julius.fr>
* Yvan Patry <yvan@julius.fr>
* Pierre <pierre@julius.fr>
* Mathieu VATEL <mathieu@julius.fr>
* Fabio Vílchez <fabio.vilchez@clearcorp.co.cr>
* Andhitia Rama <andhitia.r@gmail.com>
* Michael Viriyananda <viriyananda.michael@gmail.com>
* Aaron Henriquez <ahenriquez@forgeflow.com>
* Jared Kipe <jared@hibou.io>
* Alan Ramos <alan.ramos@jarsa.com.mx>
