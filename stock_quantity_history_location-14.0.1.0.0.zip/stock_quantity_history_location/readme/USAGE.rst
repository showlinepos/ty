* Go to:  *Inventory / Reporting / Inventory or Inventory Valuation*
* Filter by location
* **Optionally: Mark if you want to include child location**
* Choose a moment in time:
    * Current Inventory
    * At a Specific Date
