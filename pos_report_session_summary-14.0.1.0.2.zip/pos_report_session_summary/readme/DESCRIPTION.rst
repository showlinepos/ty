Add the POS Session Summary report removed in 10.0

see : https://github.com/odoo/odoo/commit/e741de8b0c152279eb2d20faa77d06df8e50b91a
