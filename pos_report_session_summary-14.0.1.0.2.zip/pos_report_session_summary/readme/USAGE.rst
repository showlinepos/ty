In a POS Session use Print -> Session Summary
