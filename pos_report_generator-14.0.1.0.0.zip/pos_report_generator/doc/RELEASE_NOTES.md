## Module <pos_report_generator>

#### 15.12.2022
#### Version 15.0.1.0.0
##### ADD
- Initial commit for pos_report_generator
